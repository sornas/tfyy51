function pkg = set_pattern(n1)
pkg = get_package('GM', n1);
end
