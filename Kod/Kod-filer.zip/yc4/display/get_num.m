function num = get_num(bytes)
num = bytes(1) + bytes(2) * 256;
end
