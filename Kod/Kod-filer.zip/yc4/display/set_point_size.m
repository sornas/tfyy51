function pkg = set_point_size(n1, n2)
arg = [n1, n2];
pkg = get_package('GZ', arg);
end
