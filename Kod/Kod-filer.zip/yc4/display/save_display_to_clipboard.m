function pkg = save_display_to_clipboard()
pkg = get_package('CB', []);
end
