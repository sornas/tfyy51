function pkg = restore_display_from_clipboard()
pkg = get_package('CR', []);
end
