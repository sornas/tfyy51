function pkg = update_bar_graph(num, val)
pkg = get_package('BA', [num, val]);
end
