function pkg = set_text_zoom(x_scale, y_scale)
pkg = get_package('ZZ', [x_scale, y_scale])
end
