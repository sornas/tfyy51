function pkg = set_line_pattern(n1)
pkg = get_package('GM', n1);
end
