#ifndef READABUFFER_H
#define READABUFFER_H

#include <windows.h>
#include "ipclink.h"


BOOL ReadABuffer(unsigned char * lpBuf, DWORD dwToWrite, HANDLE hComm);











#endif