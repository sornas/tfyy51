function pkg = invert_display()
pkg = get_package('DI', []);
end
