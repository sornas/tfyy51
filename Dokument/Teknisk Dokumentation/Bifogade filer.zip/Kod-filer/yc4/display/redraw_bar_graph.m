function pkg = redraw_bar_graph(num)
pkg = get_package('BZ', [num])
end
