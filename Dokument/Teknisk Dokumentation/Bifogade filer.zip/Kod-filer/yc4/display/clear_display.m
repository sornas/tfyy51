function pkg = clear_display()
pkg = get_package('DL', []);
end
