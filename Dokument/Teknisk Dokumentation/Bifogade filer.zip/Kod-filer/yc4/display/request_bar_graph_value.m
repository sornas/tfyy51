function pkg = request_bar_graph_value(num)
pkg = get_package('BS', [num])
end
