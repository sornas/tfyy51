function pkg = set_text_flashing(n1)
%SET_TEXT_FLASHING Summary of this function goes here
%   Detailed explanation goes here

pkg = get_package('ZB', [n1]);
end

