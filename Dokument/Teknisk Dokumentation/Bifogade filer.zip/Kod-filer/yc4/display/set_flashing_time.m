function pkg = set_flashing_time(n1)
pkg = get_package('QZ', [n1]);
end
