function pkg = continue_line(x2, y2)
arg = [get_bytes(x2), get_bytes(y2)];
pkg = get_package('GW', arg);
end
